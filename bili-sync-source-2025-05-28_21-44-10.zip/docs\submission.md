# 获取 UP 主信息

UP 主 的 ID 获取也很简单，在网页端打开想要获取投稿的 UP 主首页，直接查看网址栏中的数字或页面中的个人信息即可。

![image](./assets/submission.webp)