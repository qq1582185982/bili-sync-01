

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.DAcIqMNt.js","_app/immutable/chunks/BIirjF09.js","_app/immutable/chunks/8CRmznGO.js","_app/immutable/chunks/-rXvmcoB.js","_app/immutable/chunks/JFgP8VKp.js"];
export const stylesheets = [];
export const fonts = [];
