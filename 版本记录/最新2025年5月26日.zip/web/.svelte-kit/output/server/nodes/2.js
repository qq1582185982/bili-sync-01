

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.Uw5f9zT1.js","_app/immutable/chunks/BIirjF09.js","_app/immutable/chunks/8CRmznGO.js","_app/immutable/chunks/-rXvmcoB.js","_app/immutable/chunks/BJvmJrW7.js","_app/immutable/chunks/7INIURdn.js"];
export const stylesheets = ["_app/immutable/assets/Toaster.DKF17Rty.css"];
export const fonts = [];
