

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const universal = {
  "ssr": false,
  "prerender": true
};
export const universal_id = "src/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.BdO0JO59.js","_app/immutable/chunks/BIirjF09.js","_app/immutable/chunks/8CRmznGO.js","_app/immutable/chunks/7INIURdn.js","_app/immutable/chunks/-rXvmcoB.js","_app/immutable/chunks/BJvmJrW7.js","_app/immutable/chunks/Dw3ixo-c.js"];
export const stylesheets = ["_app/immutable/assets/Toaster.DKF17Rty.css","_app/immutable/assets/0.BfP7b87e.css"];
export const fonts = [];
