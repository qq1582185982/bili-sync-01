import { K as sanitize_props, U as rest_props, A as push, F as fallback, V as spread_attributes, P as clsx$1, G as bind_props, D as pop, Y as element, R as slot, I as ensure_array_like, S as escape_html, Z as copy_payload, _ as assign_payload, $ as head, N as attr_class, a0 as stringify } from "../../chunks/utils.js";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { tv } from "tailwind-variants";
import { a as toast } from "../../chunks/Toaster.svelte_svelte_type_style_lang.js";
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
function Input($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["class", "value", "readonly"]);
  push();
  let className = fallback($$props["class"], void 0);
  let value = fallback($$props["value"], void 0);
  let readonly = fallback($$props["readonly"], void 0);
  $$payload.out += `<input${spread_attributes(
    {
      class: clsx$1(cn("border-input bg-background ring-offset-background placeholder:text-muted-foreground focus-visible:ring-ring flex h-10 w-full rounded-md border px-3 py-2 text-sm file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", className)),
      value,
      readonly,
      ...$$restProps
    },
    null
  )}>`;
  bind_props($$props, { class: className, value, readonly });
  pop();
}
const buttonVariants = tv({
  base: "ring-offset-background focus-visible:ring-ring inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  variants: {
    variant: {
      default: "bg-primary text-primary-foreground hover:bg-primary/90",
      destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
      outline: "border-input bg-background hover:bg-accent hover:text-accent-foreground border",
      secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
      ghost: "hover:bg-accent hover:text-accent-foreground",
      link: "text-primary underline-offset-4 hover:underline"
    },
    size: {
      default: "h-10 px-4 py-2",
      sm: "h-9 rounded-md px-3",
      lg: "h-11 rounded-md px-8",
      icon: "h-10 w-10"
    }
  },
  defaultVariants: { variant: "default", size: "default" }
});
function Button($$payload, $$props) {
  push();
  let {
    class: className,
    variant = "default",
    size = "default",
    ref = null,
    href = void 0,
    type = "button",
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  if (href) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<a${spread_attributes(
      {
        class: clsx$1(cn(buttonVariants({ variant, size }), className)),
        href,
        ...restProps
      },
      null
    )}>`;
    children?.($$payload);
    $$payload.out += `<!----></a>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<button${spread_attributes(
      {
        class: clsx$1(cn(buttonVariants({ variant, size }), className)),
        type,
        ...restProps
      },
      null
    )}>`;
    children?.($$payload);
    $$payload.out += `<!----></button>`;
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { ref });
  pop();
}
function Badge($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["class", "href", "variant"]);
  push();
  let className = fallback($$props["class"], void 0);
  let href = fallback($$props["href"], void 0);
  let variant = fallback($$props["variant"], "default");
  element(
    $$payload,
    href ? "a" : "span",
    () => {
      $$payload.out += `${spread_attributes(
        {
          href,
          class: clsx$1(cn(badgeVariants({ variant, className }))),
          ...$$restProps
        },
        null
      )}`;
    },
    () => {
      $$payload.out += `<!---->`;
      slot($$payload, $$props, "default", {}, null);
      $$payload.out += `<!---->`;
    }
  );
  bind_props($$props, { class: className, href, variant });
  pop();
}
const badgeVariants = tv({
  base: "focus:ring-ring inline-flex select-none items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2",
  variants: {
    variant: {
      default: "bg-primary text-primary-foreground hover:bg-primary/80 border-transparent",
      secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 border-transparent",
      destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/80 border-transparent",
      success: "border-transparent bg-green-500 text-success-foreground",
      warning: "border-transparent bg-yellow-500 text-warning-foreground",
      outline: "text-foreground"
    }
  },
  defaultVariants: {
    variant: "default"
  }
});
const BASE_URL = "/api";
class ApiError extends Error {
  constructor(message) {
    super(message);
    this.name = "ApiError";
  }
}
async function fetchWithAuth(url, options = {}) {
  try {
    const token = localStorage.getItem("auth_token");
    const headers = {
      ...options.headers,
      "Authorization": token || ""
    };
    console.log(`请求: ${url}`, options.method || "GET");
    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`API请求失败: ${response.status} ${response.statusText}`, errorText);
      throw new ApiError(`API请求失败: ${response.status} ${response.statusText}, 响应: ${errorText}`);
    }
    const responseData = await response.json();
    if (!responseData.data && url !== `${BASE_URL}/video-sources`) {
      console.warn(`API响应缺少data字段:`, responseData);
    }
    return responseData.data;
  } catch (error) {
    console.error(`请求 ${url} 时出错:`, error);
    throw error;
  }
}
async function getVideoSources() {
  return fetchWithAuth(`${BASE_URL}/video-sources`);
}
async function listVideos(params) {
  const searchParams = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== void 0) {
      searchParams.append(key, value.toString());
    }
  });
  return fetchWithAuth(`${BASE_URL}/videos?${searchParams.toString()}`);
}
async function getVideo(id) {
  return fetchWithAuth(`${BASE_URL}/videos/${id}`);
}
async function resetVideo(id) {
  return fetchWithAuth(`${BASE_URL}/videos/${id}/reset`, { method: "POST" });
}
function VideoItem($$payload, $$props) {
  push();
  let video = $$props["video"];
  let collapseSignal = fallback($$props["collapseSignal"], false);
  let showDetail = false;
  let detail = null;
  let loading = false;
  const videoStatusLabels = ["视频封面", "视频信息", "Up主头像", "Up主信息", "分P下载"];
  const pageStatusLabels = ["视频封面", "视频内容", "视频信息", "视频弹幕", "视频字幕"];
  const statusDescriptions = [
    "未下载",
    "等待下载",
    "下载中",
    "已下载",
    "下载失败",
    "重试中",
    "暂停",
    "完成"
  ];
  const statusColorClasses = {
    "未下载": "bg-gray-100 text-gray-800",
    "等待下载": "bg-yellow-100 text-yellow-800",
    "下载中": "bg-blue-100 text-blue-800",
    "已下载": "bg-green-100 text-green-800",
    "下载失败": "bg-red-100 text-red-800",
    "重试中": "bg-orange-100 text-orange-800",
    "暂停": "bg-purple-100 text-purple-800",
    "完成": "bg-emerald-100 text-emerald-800"
  };
  let prevCollapseSignal = collapseSignal;
  async function toggleDetail() {
    showDetail = !showDetail;
    if (showDetail && (!detail || detail.video.id !== video.id)) {
      loading = true;
      detail = await getVideo(video.id);
      loading = false;
    }
  }
  async function resetVideoItem() {
    loading = true;
    try {
      const res = await resetVideo(video.id);
      const newDetail = await getVideo(video.id);
      detail = newDetail;
      video = newDetail.video;
      if (res.resetted) {
        toast.success("重置成功", {
          description: `已重置视频与视频的 ${res.pages.length} 条 page.`
        });
      } else {
        toast.info("重置无效", { description: "所有任务均成功，无需重置" });
      }
    } catch (error) {
      console.error(error);
      toast.error("重置失败", { description: `错误信息：${error}` });
    }
    loading = false;
  }
  if (collapseSignal !== prevCollapseSignal) {
    showDetail = false;
    prevCollapseSignal = collapseSignal;
  }
  const each_array = ensure_array_like(video.download_status);
  $$payload.out += `<div class="my-2 rounded border p-4"><div class="flex items-center justify-between"><div><h3>${escape_html(video.name)}</h3> <div class="flex space-x-1 flex-wrap"><!--[-->`;
  for (let i = 0, $$length = each_array.length; i < $$length; i++) {
    let status = each_array[i];
    Badge($$payload, {
      variant: "outline",
      class: status >= 0 && status < 8 ? statusColorClasses[statusDescriptions[status]] : "bg-gray-100",
      children: ($$payload2) => {
        $$payload2.out += `<!---->${escape_html(videoStatusLabels[i])}: ${escape_html(status >= 0 && status < 8 ? statusDescriptions[status] : `未知状态(${status})`)}`;
      },
      $$slots: { default: true }
    });
  }
  $$payload.out += `<!--]--></div> <p class="text-sm text-gray-500">${escape_html(video.upper_name)}</p></div> <div class="flex space-x-2">`;
  Button($$payload, {
    onclick: toggleDetail,
    children: ($$payload2) => {
      $$payload2.out += `<!---->${escape_html(showDetail ? "收起" : "展开")}`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    onclick: resetVideoItem,
    children: ($$payload2) => {
      $$payload2.out += `<!---->重置`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div></div> `;
  if (showDetail) {
    $$payload.out += "<!--[-->";
    if (loading) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<p>加载详情...</p>`;
    } else if (detail) {
      $$payload.out += "<!--[1-->";
      const each_array_1 = ensure_array_like(detail.pages);
      $$payload.out += `<div class="mt-2"><h4 class="font-semibold">视频详情</h4> <div><!--[-->`;
      for (let $$index_2 = 0, $$length = each_array_1.length; $$index_2 < $$length; $$index_2++) {
        let page = each_array_1[$$index_2];
        const each_array_2 = ensure_array_like(page.download_status);
        $$payload.out += `<div class="border-t py-1"><p>ID: ${escape_html(page.id)} - 名称: ${escape_html(page.name)}</p> <div class="flex space-x-1 flex-wrap"><!--[-->`;
        for (let i = 0, $$length2 = each_array_2.length; i < $$length2; i++) {
          let status = each_array_2[i];
          Badge($$payload, {
            variant: "outline",
            class: status >= 0 && status < 8 ? statusColorClasses[statusDescriptions[status]] : "bg-gray-100",
            children: ($$payload2) => {
              $$payload2.out += `<!---->${escape_html(pageStatusLabels[i])}: ${escape_html(status >= 0 && status < 8 ? statusDescriptions[status] : `未知状态(${status})`)}`;
            },
            $$slots: { default: true }
          });
        }
        $$payload.out += `<!--]--></div></div>`;
      }
      $$payload.out += `<!--]--></div></div>`;
    } else {
      $$payload.out += "<!--[!-->";
    }
    $$payload.out += `<!--]-->`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div>`;
  bind_props($$props, { video, collapseSignal });
  pop();
}
function Header($$payload, $$props) {
  let apiToken = localStorage.getItem("auth_token") || "";
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<header class="flex items-center justify-between bg-gray-100 p-4"><h1 class="text-xl font-bold">bili-sync 管理页</h1> <div>`;
    Input($$payload2, {
      type: "password",
      placeholder: "API Token",
      get value() {
        return apiToken;
      },
      set value($$value) {
        apiToken = $$value;
        $$settled = false;
      }
    });
    $$payload2.out += `<!----></div></header> <!---->`;
    slot($$payload2, $$props, "default", {}, null);
    $$payload2.out += `<!---->`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
}
function AddSourceForm($$payload, $$props) {
  push();
  let onSuccess = $$props["onSuccess"];
  let source_type = "collection";
  let source_id = "";
  let up_id = "";
  let name = "";
  let path = "/Downloads";
  let collection_type = "season";
  let loading = false;
  const sourceTypeLabels = {
    collection: { name: "合集", description: "合集ID可在合集页面URL中获取" },
    favorite: {
      name: "收藏夹",
      description: "收藏夹ID可在收藏夹页面URL中获取"
    },
    submission: {
      name: "UP主投稿",
      description: "UP主ID可在UP主空间URL中获取"
    },
    watch_later: { name: "稍后观看", description: "只能添加一个稍后观看源" },
    bangumi: {
      name: "番剧",
      description: "番剧season_id可在番剧页面URL中获取"
    }
  };
  const collectionTypeLabels = {
    season: {
      name: "合集",
      description: "B站标准合集，有统一的合集页面和标题-season:{mid}:{season_id}"
    },
    series: {
      name: "列表",
      description: "视频列表，组织较松散的视频合集-series:{mid}:{series_id}"
    }
  };
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<div class="bg-white p-4 rounded shadow-md"><h2 class="text-xl font-bold mb-4">添加新视频源</h2> <form class="space-y-4"><div><label class="block text-sm font-medium mb-1" for="source-type">视频源类型</label> <select id="source-type" class="w-full p-2 border rounded"><option value="collection">合集</option><option value="favorite">收藏夹</option><option value="submission">UP主投稿</option><option value="watch_later">稍后观看</option><option value="bangumi">番剧</option></select> <p class="text-xs text-gray-500 mt-1">${escape_html(sourceTypeLabels[source_type].description)}</p></div> `;
    {
      $$payload2.out += "<!--[-->";
      $$payload2.out += `<div><label class="block text-sm font-medium mb-1" for="collection-type">合集类型</label> <select id="collection-type" class="w-full p-2 border rounded"><option value="season">${escape_html(collectionTypeLabels.season.name)}</option><option value="series">${escape_html(collectionTypeLabels.series.name)}</option></select> <p class="text-xs text-gray-500 mt-1">${escape_html(collectionTypeLabels[collection_type].description)}</p></div>`;
    }
    $$payload2.out += `<!--]--> `;
    {
      $$payload2.out += "<!--[-->";
      $$payload2.out += `<div><label class="block text-sm font-medium mb-1" for="up-id">UP主ID</label> `;
      Input($$payload2, {
        id: "up-id",
        placeholder: "请输入UP主ID（可在UP主空间URL中获取）",
        get value() {
          return up_id;
        },
        set value($$value) {
          up_id = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----> <p class="text-xs text-gray-500 mt-1">UP主ID是合集所属UP主的唯一标识，必须提供</p></div>`;
    }
    $$payload2.out += `<!--]--> `;
    {
      $$payload2.out += "<!--[-->";
      $$payload2.out += `<div><label class="block text-sm font-medium mb-1" for="source-id">${escape_html("合集ID")}</label> `;
      Input($$payload2, {
        id: "source-id",
        placeholder: "请输入ID",
        get value() {
          return source_id;
        },
        set value($$value) {
          source_id = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----></div>`;
    }
    $$payload2.out += `<!--]--> <div><label class="block text-sm font-medium mb-1" for="name">名称</label> `;
    Input($$payload2, {
      id: "name",
      placeholder: "请输入名称，将显示在侧边栏",
      get value() {
        return name;
      },
      set value($$value) {
        name = $$value;
        $$settled = false;
      }
    });
    $$payload2.out += `<!----></div> <div><label class="block text-sm font-medium mb-1" for="path">保存路径</label> `;
    Input($$payload2, {
      id: "path",
      placeholder: "请输入绝对路径，如: /Downloads",
      get value() {
        return path;
      },
      set value($$value) {
        path = $$value;
        $$settled = false;
      }
    });
    $$payload2.out += `<!----> <p class="text-xs text-gray-500 mt-1">必须是绝对路径，且有写入权限</p></div> `;
    {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--> <div class="flex justify-end">`;
    Button($$payload2, {
      type: "submit",
      disabled: loading,
      children: ($$payload3) => {
        $$payload3.out += `<!---->${escape_html("添加")}`;
      },
      $$slots: { default: true }
    });
    $$payload2.out += `<!----></div></form></div>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  bind_props($$props, { onSuccess });
  pop();
}
function _page($$payload, $$props) {
  push();
  localStorage.getItem("auth_token") || "";
  const categories = [
    "collection",
    "favorite",
    "submission",
    "watch_later",
    "bangumi"
  ];
  const categoryLabels = {
    collection: "合集 (Collection)",
    favorite: "收藏夹 (Favorite)",
    submission: "UP主投稿 (Submission)",
    watch_later: "稍后观看 (Watch Later)",
    bangumi: "番剧 (Bangumi)"
  };
  const categoryDescriptions = {
    collection: "视频作者整理的系列视频合集",
    favorite: "您在B站收藏的视频内容",
    submission: "UP主发布的所有视频",
    watch_later: "添加到稍后观看的视频",
    bangumi: "B站番剧、电视剧和电影等"
  };
  let activeCategory = "collection";
  let searchQuery = "";
  let videos = [];
  let total = 0;
  let currentPage = 0;
  const pageSize = 10;
  let showAddForm = false;
  let videoListModels = {
    collection: [],
    favorite: [],
    submission: [],
    watch_later: [],
    bangumi: []
  };
  let selectedModel = null;
  let collapse = {
    collection: false,
    favorite: false,
    submission: false,
    watch_later: false,
    bangumi: false
  };
  let videoCollapseSignal = false;
  async function fetchVideoListModels() {
    try {
      videoListModels = await getVideoSources();
      for (const category of categories) {
        if (!videoListModels[category]) {
          videoListModels[category] = [];
        }
      }
      for (const key of categories) {
        if (videoListModels[key]?.length) {
          selectedModel = { category: key, id: videoListModels[key][0].id };
          break;
        }
      }
      fetchVideos();
    } catch (error) {
      console.error("获取视频源失败:", error);
      videoListModels = {
        collection: [],
        favorite: [],
        submission: [],
        watch_later: [],
        bangumi: []
      };
    }
  }
  async function fetchVideos() {
    const params = {};
    if (selectedModel && selectedModel.category === activeCategory) {
      params[`${activeCategory}`] = selectedModel.id.toString();
    }
    if (searchQuery) params.query = searchQuery;
    params.page_size = pageSize;
    params.page = currentPage;
    const listRes = await listVideos(params);
    videos = listRes.videos;
    total = listRes.total_count;
  }
  function handleAddSourceSuccess() {
    showAddForm = false;
    fetchVideoListModels();
  }
  function prevPage() {
    if (currentPage > 0) {
      currentPage -= 1;
      videoCollapseSignal = !videoCollapseSignal;
      fetchVideos();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }
  function nextPage() {
    if ((currentPage + 1) * pageSize < total) {
      currentPage += 1;
      videoCollapseSignal = !videoCollapseSignal;
      fetchVideos();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }
  fetchVideos();
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    head($$payload2, ($$payload3) => {
      $$payload3.title = `<title>bili-sync 管理页</title>`;
    });
    Header($$payload2, {
      children: ($$payload3) => {
        const each_array = ensure_array_like(categories);
        $$payload3.out += `<div class="flex"><aside class="w-1/4 border-r p-4"><div class="flex justify-between items-center mb-4"><h2 class="text-xl font-bold">视频来源</h2> `;
        Button($$payload3, {
          onclick: () => showAddForm = !showAddForm,
          class: "px-2 py-1 h-auto",
          children: ($$payload4) => {
            $$payload4.out += `<!---->${escape_html(showAddForm ? "取消" : "添加")}`;
          },
          $$slots: { default: true }
        });
        $$payload3.out += `<!----></div> `;
        if (showAddForm) {
          $$payload3.out += "<!--[-->";
          $$payload3.out += `<div class="mb-4">`;
          AddSourceForm($$payload3, { onSuccess: handleAddSourceSuccess });
          $$payload3.out += `<!----></div>`;
        } else {
          $$payload3.out += "<!--[!-->";
        }
        $$payload3.out += `<!--]--> <!--[-->`;
        for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
          let cat = each_array[$$index_1];
          $$payload3.out += `<div class="mb-4"><button class="w-full text-left font-semibold">${escape_html(categoryLabels[cat] || cat)}
						${escape_html(collapse[cat] ? "▶" : "▼")}</button> <p class="text-xs text-gray-500 mb-1">${escape_html(categoryDescriptions[cat])}</p> `;
          if (!collapse[cat]) {
            $$payload3.out += "<!--[-->";
            if (videoListModels[cat]?.length) {
              $$payload3.out += "<!--[-->";
              const each_array_1 = ensure_array_like(videoListModels[cat]);
              $$payload3.out += `<ul class="ml-4"><!--[-->`;
              for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
                let model = each_array_1[$$index];
                $$payload3.out += `<li class="mb-1 flex items-center"><button${attr_class(`flex-grow rounded px-2 py-1 text-left hover:bg-gray-100 ${stringify(selectedModel && selectedModel.category === cat && selectedModel.id === model.id ? "bg-gray-200" : "")}`)}>${escape_html(model.name)}</button> <button class="ml-1 text-red-500 hover:text-red-700 px-2" title="删除">×</button></li>`;
              }
              $$payload3.out += `<!--]--></ul>`;
            } else {
              $$payload3.out += "<!--[!-->";
              $$payload3.out += `<p class="ml-4 text-gray-500">无数据</p>`;
            }
            $$payload3.out += `<!--]-->`;
          } else {
            $$payload3.out += "<!--[!-->";
          }
          $$payload3.out += `<!--]--></div>`;
        }
        $$payload3.out += `<!--]--></aside> <main class="flex-1 p-4"><div class="mb-4">`;
        Input($$payload3, {
          placeholder: "搜索视频...",
          get value() {
            return searchQuery;
          },
          set value($$value) {
            searchQuery = $$value;
            $$settled = false;
          }
        });
        $$payload3.out += `<!----></div> `;
        if (videos.length > 0) {
          $$payload3.out += "<!--[-->";
          const each_array_2 = ensure_array_like(videos);
          $$payload3.out += `<div><!--[-->`;
          for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
            let video = each_array_2[$$index_2];
            VideoItem($$payload3, { video, collapseSignal: videoCollapseSignal });
          }
          $$payload3.out += `<!--]--></div> <div class="mt-4 flex items-center justify-between">`;
          Button($$payload3, {
            onclick: prevPage,
            disabled: currentPage === 0,
            children: ($$payload4) => {
              $$payload4.out += `<!---->上一页`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> <span>第 ${escape_html(currentPage + 1)} 页，共 ${escape_html(Math.ceil(total / pageSize))} 页</span> `;
          Button($$payload3, {
            onclick: nextPage,
            disabled: (currentPage + 1) * pageSize >= total,
            children: ($$payload4) => {
              $$payload4.out += `<!---->下一页`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----></div>`;
        } else {
          $$payload3.out += "<!--[!-->";
          $$payload3.out += `<div class="text-center py-8 text-gray-500">无数据，请选择或添加视频源</div>`;
        }
        $$payload3.out += `<!--]--></main></div>`;
      },
      $$slots: { default: true }
    });
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
export {
  _page as default
};
