const ssr = false;
const prerender = true;
export {
  prerender,
  ssr
};
