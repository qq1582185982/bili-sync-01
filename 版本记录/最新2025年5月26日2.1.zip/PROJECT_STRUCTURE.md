# bili-sync 项目结构说明

## 项目概述
bili-sync 是一个哔哩哔哩视频同步工具，使用 Rust 后端 + Svelte 前端架构。

## 目录结构

```
├── crates/                 # Rust 后端代码
│   ├── bili_sync/          # 主应用程序
│   ├── bili_sync_entity/   # 数据库实体定义
│   └── bili_sync_migration/# 数据库迁移脚本
├── web/                    # Svelte 前端应用
│   ├── src/               # 前端源代码
│   ├── static/            # 静态资源
│   └── build/             # 构建输出
├── docs/                   # VitePress 文档站点
├── scripts/                # 辅助工具脚本
├── assets/                 # 项目资源文件
├── target/                 # Rust 编译输出 (gitignore)
├── make.bat               # Windows 批处理任务脚本
├── make.ps1               # PowerShell 任务脚本
├── Cargo.toml             # Rust 工作空间配置
├── docker-compose.yml     # Docker 部署配置
└── README.md              # 项目说明
```

## 开发流程

### 后端开发
```bash
# 运行后端
cargo run --bin bili_sync

# 运行测试
cargo test

# 构建发布版本
cargo build --release
```

### 前端开发
```bash
cd web
npm install
npm run dev        # 开发模式
npm run build      # 构建生产版本
```

### 文档开发
```bash
cd docs
npm install
npm run dev        # 本地预览文档
npm run build      # 构建文档
```

### 使用任务脚本
```bash
# Windows 批处理脚本（推荐）
.\make.bat help
.\make.bat setup
.\make.bat dev

# PowerShell 脚本
.\make.ps1 help
.\make.ps1 setup
.\make.ps1 dev
```

## 主要组件

### 后端 (Rust)
- **bili_sync**: 主应用，包含 API 服务器和下载逻辑
- **bili_sync_entity**: 数据库实体和模型
- **bili_sync_migration**: 数据库迁移管理

### 前端 (Svelte)
- 管理界面，运行在 `0.0.0.0:12345`
- 支持添加视频源、监控下载状态等功能

### 数据库
- 使用 SQLite 存储媒体信息和配置
- 通过 SeaORM 进行数据库操作

### 辅助工具
- **scripts/2.0.3_add_fanart.py**: 版本升级时的 fanart 添加工具
- **scripts/tools/compress_image.py**: 图片压缩工具

## 部署方式
1. **Docker**: 使用 `docker-compose.yml`
2. **二进制**: 直接运行编译后的可执行文件
3. **源码**: 从源码编译运行 