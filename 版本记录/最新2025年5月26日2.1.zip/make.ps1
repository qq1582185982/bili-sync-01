# bili-sync Project Tasks (PowerShell)

param(
    [string]$Task = "help"
)

function Show-Help {
    Write-Host "bili-sync 可用任务:" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "开发任务:" -ForegroundColor Yellow
    Write-Host "  setup     - 设置开发环境"
    Write-Host "  dev       - 启动开发服务器"
    Write-Host "  test      - 运行测试"
    Write-Host "  fmt       - 格式化代码"
    Write-Host "  lint      - 代码检查"
    Write-Host ""
    Write-Host "构建任务:" -ForegroundColor Yellow
    Write-Host "  build     - 构建项目"
    Write-Host "  release   - 构建发布版本"
    Write-Host "  clean     - 清理构建文件"
    Write-Host ""
    Write-Host "文档任务:" -ForegroundColor Yellow
    Write-Host "  docs      - 启动文档服务器"
    Write-Host "  docs-build- 构建文档"
    Write-Host ""
    Write-Host "Docker 任务:" -ForegroundColor Yellow
    Write-Host "  docker    - 构建 Docker 镜像"
    Write-Host "  compose   - 启动 Docker Compose"
    Write-Host ""
    Write-Host "用法: .\make.ps1 <任务名>" -ForegroundColor Green
}

function Setup-Dev {
    Write-Host "Setting up development environment..." -ForegroundColor Green
    
    # Check Rust
    Write-Host "Checking Rust environment..." -ForegroundColor Yellow
    if (!(Get-Command "cargo" -ErrorAction SilentlyContinue)) {
        Write-Host "Rust not found. Please install Rust: https://rustup.rs/" -ForegroundColor Red
        exit 1
    }
    Write-Host "Rust environment OK" -ForegroundColor Green
    
    # Check Node.js
    Write-Host "Checking Node.js environment..." -ForegroundColor Yellow
    if (!(Get-Command "node" -ErrorAction SilentlyContinue)) {
        Write-Host "Node.js not found. Please install Node.js: https://nodejs.org/" -ForegroundColor Red
        exit 1
    }
    Write-Host "Node.js environment OK" -ForegroundColor Green
    
    # Install Rust dependencies
    Write-Host "Installing Rust dependencies..." -ForegroundColor Yellow
    cargo check
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Failed to install Rust dependencies" -ForegroundColor Red
        exit 1
    }
    Write-Host "Rust dependencies installed" -ForegroundColor Green
    
    # Install frontend dependencies
    Write-Host "Installing frontend dependencies..." -ForegroundColor Yellow
    Set-Location web
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Failed to install frontend dependencies" -ForegroundColor Red
        exit 1
    }
    Set-Location ..
    Write-Host "Frontend dependencies installed" -ForegroundColor Green
    
    # Install docs dependencies
    Write-Host "Installing documentation dependencies..." -ForegroundColor Yellow
    Set-Location docs
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Failed to install documentation dependencies" -ForegroundColor Red
        exit 1
    }
    Set-Location ..
    Write-Host "Documentation dependencies installed" -ForegroundColor Green
    
    Write-Host "Development environment setup complete!" -ForegroundColor Green
}

function Start-Dev {
    Write-Host "Starting development servers..." -ForegroundColor Green
    
    Write-Host "Starting Rust backend..." -ForegroundColor Green
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cargo run --bin bili_sync"
    
    Start-Sleep 2
    
    Write-Host "Starting Svelte frontend..." -ForegroundColor Green
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd web; npm run dev"
    
    Write-Host "All services started!" -ForegroundColor Green
    Write-Host "Backend API: http://localhost:12345" -ForegroundColor White
    Write-Host "Frontend UI: http://localhost:5173" -ForegroundColor White
}

function Run-Tests {
    Write-Host "Running tests..." -ForegroundColor Green
    cargo test
    if ($LASTEXITCODE -eq 0) {
        Write-Host "All tests passed" -ForegroundColor Green
    } else {
        Write-Host "Tests failed" -ForegroundColor Red
    }
}

function Format-Code {
    Write-Host "Formatting code..." -ForegroundColor Green
    cargo fmt
    Write-Host "Code formatting complete" -ForegroundColor Green
}

function Lint-Code {
    Write-Host "Linting code..." -ForegroundColor Green
    cargo clippy -- -D warnings
}

function Build-Project {
    Write-Host "Building project..." -ForegroundColor Green
    cargo build
    Set-Location web
    npm run build
    Set-Location ..
    Write-Host "Project build complete" -ForegroundColor Green
}

function Build-Release {
    Write-Host "Building release version..." -ForegroundColor Green
    cargo build --release
    Set-Location web
    npm run build
    Set-Location ..
    Write-Host "Release build complete" -ForegroundColor Green
}

function Clean-Build {
    Write-Host "Cleaning build files..." -ForegroundColor Green
    cargo clean
    if (Test-Path "web/build") { Remove-Item -Recurse -Force "web/build" }
    if (Test-Path "web/.svelte-kit") { Remove-Item -Recurse -Force "web/.svelte-kit" }
    if (Test-Path "docs/.vitepress/dist") { Remove-Item -Recurse -Force "docs/.vitepress/dist" }
    Write-Host "Clean complete" -ForegroundColor Green
}

function Start-Docs {
    Write-Host "Starting documentation server..." -ForegroundColor Green
    Set-Location docs
    npm run dev
    Set-Location ..
}

function Build-Docs {
    Write-Host "Building documentation..." -ForegroundColor Green
    Set-Location docs
    npm run build
    Set-Location ..
    Write-Host "Documentation build complete" -ForegroundColor Green
}

function Build-Docker {
    Write-Host "Building Docker image..." -ForegroundColor Green
    docker build -t bili-sync .
}

function Start-Compose {
    Write-Host "Starting Docker Compose..." -ForegroundColor Green
    docker-compose up -d
}

switch ($Task.ToLower()) {
    "help" { Show-Help }
    "setup" { Setup-Dev }
    "dev" { Start-Dev }
    "test" { Run-Tests }
    "fmt" { Format-Code }
    "lint" { Lint-Code }
    "build" { Build-Project }
    "release" { Build-Release }
    "clean" { Clean-Build }
    "docs" { Start-Docs }
    "docs-build" { Build-Docs }
    "docker" { Build-Docker }
    "compose" { Start-Compose }
    default {
        Write-Host "Unknown task: $Task" -ForegroundColor Red
        Show-Help
    }
} 