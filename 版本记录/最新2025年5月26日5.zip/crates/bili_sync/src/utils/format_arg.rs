use serde_json::json;
use regex;

use crate::config::CONFIG;

pub fn video_format_args(video_model: &bili_sync_entity::video::Model) -> serde_json::Value {
    json!({
        "bvid": &video_model.bvid,
        "title": &video_model.name,
        "upper_name": &video_model.upper_name,
        "upper_mid": &video_model.upper_id,
        "pubtime": &video_model.pubtime.and_utc().format(&CONFIG.time_format).to_string(),
        "fav_time": &video_model.favtime.and_utc().format(&CONFIG.time_format).to_string(),
        "show_title": &video_model.name,
    })
}

/// 番剧专用的格式化函数，使用番剧自己的模板配置
pub fn bangumi_page_format_args(
    video_model: &bili_sync_entity::video::Model,
    page_model: &bili_sync_entity::page::Model,
) -> serde_json::Value {
    // 从视频名称中提取集数，例如 "第1话 满级了" -> "1"
    let episode_number = extract_episode_number(&video_model.name);
    
    json!({
        "bvid": &video_model.bvid,
        "title": &video_model.name,
        "upper_name": &video_model.upper_name,
        "upper_mid": &video_model.upper_id,
        "ptitle": &page_model.name,
        "pid": episode_number,
        "pid_pad": format!("{:02}", episode_number),
        "pubtime": video_model.pubtime.and_utc().format(&CONFIG.time_format).to_string(),
        "fav_time": video_model.favtime.and_utc().format(&CONFIG.time_format).to_string(),
        "long_title": &page_model.name,
        "show_title": format!("E{:02} - {}", episode_number, page_model.name),
        "episode_title": format!("第{}话 {}", episode_number, page_model.name),
    })
}

/// 从番剧视频名称中提取集数
fn extract_episode_number(video_name: &str) -> i32 {
    // 尝试匹配 "第X话"、"第X集"、"第X期" 格式
    if let Some(captures) = regex::Regex::new(r"第(\d+)[话集期]").unwrap().captures(video_name) {
        if let Some(number_str) = captures.get(1) {
            if let Ok(number) = number_str.as_str().parse::<i32>() {
                return number;
            }
        }
    }
    
    // 如果没有匹配到，尝试匹配开头的数字
    if let Some(captures) = regex::Regex::new(r"^(\d+)").unwrap().captures(video_name) {
        if let Some(number_str) = captures.get(1) {
            if let Ok(number) = number_str.as_str().parse::<i32>() {
                return number;
            }
        }
    }
    
    // 默认返回1
    1
}

pub fn page_format_args(
    video_model: &bili_sync_entity::video::Model,
    page_model: &bili_sync_entity::page::Model,
) -> serde_json::Value {
    // 检查是否为番剧类型
    let is_bangumi = match video_model.source_type {
        Some(1) => true,  // source_type = 1 表示为番剧
        _ => false,
    };
    
    // 对于番剧，使用专门的格式化函数
    if is_bangumi {
        bangumi_page_format_args(video_model, page_model)
    } else {
        json!({
            "bvid": &video_model.bvid,
            "title": &video_model.name,
            "upper_name": &video_model.upper_name,
            "upper_mid": &video_model.upper_id,
            "ptitle": &page_model.name,
            "pid": page_model.pid,
            "pid_pad": format!("{:02}", page_model.pid),
            "pubtime": video_model.pubtime.and_utc().format(&CONFIG.time_format).to_string(),
            "fav_time": video_model.favtime.and_utc().format(&CONFIG.time_format).to_string(),
            "long_title": &page_model.name,
            "show_title": &page_model.name,
        })
    }
}
