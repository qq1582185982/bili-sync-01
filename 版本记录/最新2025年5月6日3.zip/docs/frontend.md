# 管理页

在 2.4.0 版本，bili-sync 提供了一个内置的管理页，可以使用浏览器访问，实现一些简单的预览和重置操作。

由于作者的前端水平有限，网页使用 90% AI + 10% 人工实现，问题会比较多，欢迎前端大能 PR（应该说比起 PR 缝缝补补不如直接重写 XD）。

![frontend](./assets/frontend.webp)

# API

后端提供的 API 可以通过 `/swagger-ui/` 访问：

![swagger](./assets/swagger.webp)
