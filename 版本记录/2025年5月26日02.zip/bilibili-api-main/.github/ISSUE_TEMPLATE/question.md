---
name: 提出疑问
about: 使用该模板进行提问
title: "[提问] 这里填写标题"
labels: 'question'
assignees: ''

---

**Python 版本：** 3.x.y

**模块版本：** x.y.z <!--可使用 bilibili_api.BILIBILI_API_VERSION 或 pip3 show bilibili-api-python 查询-->

**运行环境：** Windows / Linux / MacOS

<!-- 务必提供模块版本并确保为最新版 -->

---

在此处写正文
