import os

# Check the code.
exit(os.system("pylint -E ./bilibili_api"))
