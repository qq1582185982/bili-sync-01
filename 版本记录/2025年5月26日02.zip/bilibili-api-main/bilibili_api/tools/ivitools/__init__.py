"""
IVITools

A Simple IVI file manager & toolbox. 

BY Nemo2011 <yimoxia@outlook.com>

Licensed under the GNU General Public License v3+. 
"""
