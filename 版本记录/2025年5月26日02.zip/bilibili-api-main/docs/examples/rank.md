# 示例：获取全站排行榜

``` python
from bilibili_api import rank, sync

print(sync(rank.get_rank()))
```
