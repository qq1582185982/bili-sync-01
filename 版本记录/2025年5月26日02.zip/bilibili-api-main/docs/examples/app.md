# 示例：获取开屏图片

``` python
from bilibili_api import app, sync

print(sync(app.get_loading_images()))
```
