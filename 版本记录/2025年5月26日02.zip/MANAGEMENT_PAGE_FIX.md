# 管理页合集添加功能修复

## 问题描述

在之前的实现中，管理页添加合集时使用了硬编码的UP主ID `123456789`，这导致：

1. 生成的配置格式 `series:123456789:387214` 使用了假的UP主ID
2. B站API无法找到对应的合集内容，显示 "no videos found in collection"
3. 用户无法正常添加和使用合集功能

## 解决方案

### 方案1：修复管理页逻辑（已实施）

让用户可以自己设置真实的UP主ID，确保合集功能正常工作。

## 修复内容

### 1. 前端修改

#### `web/src/lib/components/AddSourceForm.svelte`
- 添加了 `up_id` 字段用于存储用户输入的UP主ID
- 为合集类型添加了专门的UP主ID输入框
- 添加了表单验证，确保合集类型必须提供UP主ID
- 更新了表单重置逻辑，包含新的UP主ID字段

#### `web/src/lib/api.ts`
- 在 `addVideoSource` 函数的参数类型中添加了 `up_id?: string` 字段

### 2. 后端修改

#### `crates/bili_sync/src/api/request.rs`
- 在 `AddVideoSourceRequest` 结构体中添加了 `up_id: Option<String>` 字段
- 添加了相应的文档注释说明该字段的用途

#### `crates/bili_sync/src/api/handler.rs`
- 添加了合集类型的UP主ID验证逻辑
- 修改了数据库插入逻辑，使用用户提供的UP主ID而不是硬编码值
- 更新了配置文件生成逻辑，使用正确的格式 `type:real_mid:sid`

## 用户界面改进

### 添加合集时的新界面

1. **视频源类型**：选择"合集"
2. **合集类型**：选择"合集"或"列表"
3. **UP主ID**：用户必须输入真实的UP主ID（新增字段）
4. **合集ID**：输入合集的ID
5. **名称**：为合集设置显示名称
6. **保存路径**：设置下载路径

### 用户体验优化

- 添加了清晰的字段说明和提示文本
- UP主ID字段有详细的说明："UP主ID是合集所属UP主的唯一标识，必须提供"
- 表单验证确保用户不会遗漏必要信息

## 技术细节

### 配置格式

修复前（错误）：
```
[collection_list]
"season:123456789:387214" = "/Downloads"
```

修复后（正确）：
```
[collection_list]
"season:real_up_id:387214" = "/Downloads"
```

### 数据库存储

- `collection` 表的 `m_id` 字段现在存储真实的UP主ID
- 确保数据的一致性和有效性

## 测试验证

1. **编译测试**：✅ 通过
   - 后端 Rust 代码编译成功
   - 前端 TypeScript/Svelte 代码构建成功

2. **功能测试**：需要用户验证
   - 添加合集时必须提供UP主ID
   - 生成的配置使用真实的UP主ID
   - B站API能够正确获取合集内容

## 向后兼容性

- 现有的合集配置不会受到影响
- 新添加的合集将使用正确的UP主ID
- 用户可以手动修复现有的错误配置

## 使用说明

### 如何获取UP主ID

1. 访问UP主的空间页面
2. 从URL中获取UP主ID，例如：
   - URL: `https://space.bilibili.com/123456789`
   - UP主ID: `123456789`

### 如何获取合集ID

1. 访问合集页面
2. 从URL中获取合集ID，例如：
   - 合集URL: `https://space.bilibili.com/123456789/channel/collectiondetail?sid=387214`
   - 合集ID: `387214`

## 修复状态

- ✅ 前端UI修改完成
- ✅ 后端API修改完成
- ✅ 数据验证逻辑完成
- ✅ 编译测试通过
- 🔄 等待用户功能测试

这个修复解决了PR #339中提到的管理页添加合集时使用硬编码UP主ID的问题，确保了合集功能的正常工作。 